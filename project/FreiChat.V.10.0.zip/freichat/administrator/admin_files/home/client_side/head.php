<script>
        function helpme1()
    {
        var str="This option removes conflicts with other extensions using jquery.\n\nThis option should be set to yes only and only if freichat is not working because of some external jquery conflicts. \n\nUse this option only if freichat doesnt work normally.";
        alert(str);
    }
</script>