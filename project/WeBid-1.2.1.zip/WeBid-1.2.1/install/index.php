<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>WeBid Installer</title>
</head>

<body>
<p><a href="install.php">Install</a></p>
<p><a href="update.php">Update</a></p>
</body>
</html>
