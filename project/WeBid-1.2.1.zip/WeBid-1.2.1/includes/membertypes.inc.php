<?php
$membertypes = array(
'9' => array(
	'id' => '24', 'feedbacks' => '9', 'icon' => 'transparent.gif'
	),
'49' => array(
	'id' => '14', 'feedbacks' => '49', 'icon' => 'starY.gif'
	),
'50' => array(
	'id' => '26', 'feedbacks' => '50', 'icon' => 'starFR.gif'
	),
'99' => array(
	'id' => '15', 'feedbacks' => '99', 'icon' => 'starB.gif'
	),
'999' => array(
	'id' => '16', 'feedbacks' => '999', 'icon' => 'starT.gif'
	),
'4999' => array(
	'id' => '17', 'feedbacks' => '4999', 'icon' => 'starR.gif'
	),
'9999' => array(
	'id' => '23', 'feedbacks' => '9999', 'icon' => 'starG.gif'
	),
'24999' => array(
	'id' => '19', 'feedbacks' => '24999', 'icon' => 'starFY.gif'
	),
'49999' => array(
	'id' => '20', 'feedbacks' => '49999', 'icon' => 'starFT.gif'
	),
'99999' => array(
	'id' => '22', 'feedbacks' => '99999', 'icon' => 'starFR.gif'
	),
'999999' => array(
	'id' => '21', 'feedbacks' => '999999', 'icon' => 'starFV.gif'
	)
);