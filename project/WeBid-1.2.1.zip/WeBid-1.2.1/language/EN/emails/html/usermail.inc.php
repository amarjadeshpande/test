<table border="0" width="100%">
	<tr>
		<td colspan="2" height="35"><div style="font-size: 14px; font-weight: bold;">Complete Your {SITENAME} Registration!</div></td>
	</tr>
	<tr>
		<td colspan="2" style="font-size: 12px;">Hello <b>{C_NAME}</b>,</td>
	</tr>
	<tr>
		<td colspan="2" height="50" style="font-size: 12px; padding-right: 6px;">
		Just click "Activate Me" to complete your registration. Once you do that you are ready to
		start buying/selling on {SITENAME}
		</td>
	</tr>
	<tr>
		<td width="55%" rowspan="2" valign="top"><br /><br />
		<table border="0" width="100%">
			<tr>
				<td style="font-size: 12px; padding-bottom: 7px; padding-top: 5px;"><b>If the link does not work:</b></td>
			</tr>
			<tr>
				<td style="font-size: 12px;">Please email us at <a href="mailto:{ADMINMAIL}">{ADMINMAIL}</a></td>
			</tr>
		</table>
		</td>
		<td width="34%" style="font-size: 12px;">Continue To Confirm</td>
	</tr>
	<tr>
		<td width="34%" height="176" valign="top">
		<a href="{CONFIRMURL}">
		<img border="0" src="{SITEURL}images/email_alerts/Active_Acct_Btn.jpg" width="120" height="32"></a></td>
	</tr>
</table>