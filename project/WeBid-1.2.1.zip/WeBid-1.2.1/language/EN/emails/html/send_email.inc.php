Dear {SELLER_NICK},<br>
<br>
This message is sent from {SITENAME}.<br>
<br>
{SENDER_NAME} at <a href="mailto:{SENDER_EMAIL}">{SENDER_EMAIL}</a> has a question for you regarding your auction {TITLE}.<br>
<br>
Question:<br>
{SENDER_QUESTION}<br>
<br>
Auction URL: <a href="{SITEURL}item.php?id={AID}">{SITEURL}item.php?id={AID}</a><br>
<br>
Thank you for being a part of {SITENAME}<br>
<a href="{SITEURL}">{SITEURL}</a><br>