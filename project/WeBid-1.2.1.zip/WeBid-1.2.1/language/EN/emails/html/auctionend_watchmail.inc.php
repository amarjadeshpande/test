Dear {NAME},<br>
<br>
This is an automatic response from Your Item Watch.<br>
The auction closed which was on your Item Watch list.<br>
<br>
Auction Title: {TITLE}<br>
Auction URL: <a href="{URL}">{URL}</a>