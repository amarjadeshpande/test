Dear {C_NAME},
Your item has been successfully listed on {SITENAME} and will appear to other users after it has been approved.

Here are the listing details:

Auction title: {A_TITLE}
Auction type: {A_TYPE}
Item #: {A_ID}
Starting bid: {A_MINBID}
Reserve price: {A_RESERVE}
Buy Now price: {A_BNPRICE}
End time: {A_ENDS}

{SITE_URL}item.php?id={A_ID}

Have another item to list?
{SITE_URL}select_category.php
